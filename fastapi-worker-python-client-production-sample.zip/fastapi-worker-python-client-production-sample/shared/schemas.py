from __future__ import annotations

from datetime import datetime
from pydantic import BaseModel


class TokenRequest(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = 'bearer'
    expires_in_seconds: int
    tenant_id: str
    user_id: str
    role: str


class JobCreateResponse(BaseModel):
    job_id: str
    status: str
    message: str
    status_url: str
    result_url: str
    websocket_url: str
    trace_id: str


class JobStatusResponse(BaseModel):
    job_id: str
    tenant_id: str
    user_id: str
    filename: str
    status: str
    progress: int
    message: str
    attempts: int
    upload_object_key: str
    result_object_key: str | None = None
    error: str | None = None
    created_at: datetime
    updated_at: datetime
    finished_at: datetime | None = None
    trace_id: str
